
import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAdd: UITextField!
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var tbl: UITableView!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
       
    }

    @IBAction func btnInsert(_ sender: Any)
    {
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {   let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        return cell ?? "fjhg"
        
    }
}

